<?php
defined('BASEPATH') OR exit('No direct script access allowed');

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

///You can get this variable by creating app on dropbox
$config['app_key'] = 'Your Key';
$config['app_secret'] = 'Your Secret';


///Set up this variable after you accept dropbox request
$config['oauth_token'] = 'Oauth token';
$config['oauth_token_secret'] = 'oauth secret';

